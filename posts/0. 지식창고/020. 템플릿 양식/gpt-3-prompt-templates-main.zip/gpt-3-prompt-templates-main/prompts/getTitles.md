---
PromptInfo:
 promptId: getTitles
 name: 🗃️ Get Blog Titles
 description: select a content and list of blog titles will be generated
 author: Noureddine
 tags: writing
 version: 0.0.1
---
content: 
{{context}}
prompt:
suggest 10 attractive blog titles about this content:


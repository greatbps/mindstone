---
PromptInfo:
 promptId: simplify
 name: 👼Simplify 
 description: select a content and it will be simplified.
 author: Noureddine
 tags: thinking, writing
 version: 0.0.1
---
content: 
{{context}}
prompt:
make the content very clear and easy to understand

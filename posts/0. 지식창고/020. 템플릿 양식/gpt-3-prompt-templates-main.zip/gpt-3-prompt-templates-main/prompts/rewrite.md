---
PromptInfo:
 promptId: rewrite
 name: ✏️ Rewrite, Paraphrase 
 description: select a content and it will be rewriten.
 author: Noureddine
 tags: writing
 version: 0.0.1
---
content: 
{{context}}
prompt:
rewrite the content to make it more attractive

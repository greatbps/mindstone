---
PromptInfo:
 promptId: getParagraph
 name: ✍️ Write paragraph
 description: select one item, a paragraph will be generated.
 required_values: title, outline
 author: Noureddine
 tags: writing
 version: 0.0.1
---
title:
{{title}}
outline:
{{outline}}

# {{context}}

---
PromptInfo:
 promptId: getEmailNeg
 name: ✉️ Reply to Email negatively 😡
 description: select the email content and negative reply will be generated
 author: Noureddine
 tags: communication, email
 version: 0.0.1
---
prompt:
reply to this email negatively in professional way. 
email: 
{{context}}
reply: 

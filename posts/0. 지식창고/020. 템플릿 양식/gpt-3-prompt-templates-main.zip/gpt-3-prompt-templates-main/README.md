# gpt-3-prompt-templates
This repo contains a collection of templates for use with the gpt-3 text generation model.
